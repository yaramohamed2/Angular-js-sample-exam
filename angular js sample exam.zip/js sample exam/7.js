
var arr=["AngulaJS","Node.js","JQuery"];  
var rev=arr.reverse();  
document.writeln(rev);