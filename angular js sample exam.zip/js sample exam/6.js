function isEmpty(){
    const NameField= document.querySelector("#Fullname");

    if (!NameField.value){
        return true;}
        else{
            return false;
        }
        
    
}
const isFieldEmpty= isEmpty();

if(isFieldEmpty){
    console.log("The name field is required");
}

