const arr = [30, 20, 50, 70, 10, 40, 17];

let max_val = arr[0];
let max_index = 0;

for (let i=0; i < arr.length; i++) {
    if (arr[i] > max_val) {
        max_val = arr[i];
        max_index = i;
    }
}

document.write("Maximum value is: " + max_val);
document.write("Maximum value index is: " + max_index);